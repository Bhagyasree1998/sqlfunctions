import com.arth.Arithmetic;
import com.comp.Comparison;
import com.inc.Operators;
import com.assignment.*;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Arithmetic a=new Arithmetic();
		a.arithmetic();
		Comparison c =new Comparison();
		c.comparison();
		Operators d=new Operators();
		d.operators();
		Assignment ae=new Assignment();
		ae.assignmentOperators();
		
	}

}
