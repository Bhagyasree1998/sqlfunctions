package com.comp;

public class Comparison {
	public int a=10;
	public int b=20;
	public void comparison()
	{
		System.out.println("(a==b) : "+(a==b));
		System.out.println("(a!=b) : "+(a!=b));
		System.out.println("(a>b) : "+(a>b));
		System.out.println("(a>=b) : "+(a>=b));
		System.out.println("(a<=b) : "+(a>=b));
		
	}

}
