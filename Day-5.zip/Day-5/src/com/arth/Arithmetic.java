package com.arth;

public class Arithmetic {
	public int a=10;
	public int b=20;
	public void arithmetic()
	{
		System.out.println("Addition of a,b is : "+(a+b));
		System.out.println("Subtraction of a,b is : "+(a-b));
		System.out.println("Multiplication of a,b is : "+(a*b));
		System.out.println("Division of a,b is : "+(a/b));
		System.out.println("Module of a,b is : "+(a%b));
	}
	

}
