package com.assignment;

public class Assignment {
	public int a=18;
	public void assignmentOperators() {
		System.out.println("a+=3 :" + (a+=3));
		System.out.println("a+=3 :" + (a-=6));
		System.out.println("a+=3 :" +(a*=5));
		System.out.println("a+=3 :" + (a/=8));
		
		
		
		
	}

}
