package com.wrap;
import java.lang.StringBuffer;
public class StringBufferEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Bhagya";
		StringBuffer sb=new StringBuffer(str);
		System.out.println(str); 
		System.out.println(sb.append(10));
		System.out.println(sb.length());
		System.out.println(sb.insert(1,"Java"));
		System.out.println(sb.replace(1,3,"Java"));
		System.out.println(sb.delete(1,3));
		System.out.println(sb.reverse());
		System.out.println(sb.capacity());
	    sb.ensureCapacity(10);
	    System.out.println(sb.capacity());
        sb.ensureCapacity(50);
		System.out.println(sb.capacity());
		sb.trimToSize();
		System.out.println(sb.capacity());
		
		char[] cstr = new char[] { 'i', 's', 'a', 'g', 'o', 'o', 'd', 'g', 
                'i', 'r', 'l', 'k', 'e', 'e', 'r' };  
		System.out.println(sb.append(cstr, 0, 8));
		System.out.println(sb.appendCodePoint(65));
		int codepoints = str.codePointCount(4, 7);
		System.out.println(codepoints);
		
		

	}

}
