package com.wrap;

public class StringBuilderr {
	public static void main(String[] args) {
	String str="Bhagyasree";
	StringBuilder s=new StringBuilder(str);
	System.out.println(str); 
	System.out.println(s.append(10));
	System.out.println(s.length());
	System.out.println(s.insert(1,"Java"));
	System.out.println(s.replace(1,3,"Java"));
	System.out.println(s.delete(1,3));
	System.out.println(s.reverse());
	System.out.println(s.capacity());
    s.ensureCapacity(10);
    System.out.println(s.capacity());
    s.ensureCapacity(50);
	System.out.println(s.capacity());
	s.trimToSize();
	System.out.println(s.capacity());
	
	char[] cstr = new char[] { 'i', 's', 'a', 'g', 'o', 'o', 'd', 'g', 
            'i', 'r', 'l', 'k', 'e', 'e', 'r' };  
	System.out.println(s.append(cstr, 0, 8));
	System.out.println(s.appendCodePoint(65));
	int codepoints = str.codePointCount(4, 7);
	System.out.println(codepoints);
}

}
