package com.inc;

public class Operators {
	public int a=10;
	public int b=20;
	
	public void operators() {
		System.out.println("Increment : " + ++a);
	    System.out.println("decrement : " + --b);
	    System.out.println("OR : " + (a|b));
	    System.out.println("AND : " + (a&b));
	    System.out.println("Complement : " + (~a));
	    System.out.println("Right Shift : " + (a>>1 ));
	    System.out.println("left Shift : " + (a<<1 ));
	}

}
