package com.src;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class junittestinng {

	@Test
	void testFiles() {
		fail("Not yet implemented");
	}

}
