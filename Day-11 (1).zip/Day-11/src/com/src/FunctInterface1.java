package com.src;
public interface FunctInterface1{
public class ThreadEx extends Thread{
	public void run()
	{
		
	}
	}


}
