package com.src;

public class MainMethod1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Thread(()->{System.out.println("running");}).start();
	}

}
