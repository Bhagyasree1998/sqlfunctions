package com.src;

public interface FucntInterface {
	public void string(String a,String b);

}
