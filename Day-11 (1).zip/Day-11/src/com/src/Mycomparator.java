package com.src;

public interface Mycomparator {
	public int compare(Object o1,Object o2);

}
