import java.util.Scanner;
public class SecondProg {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
				int a,b,c;
				System.out.println("enter first subject marks : ");
				a=sc.nextInt();
				System.out.println("enter second subject marks : ");
				b=sc.nextInt();
				System.out.println("enter third subject marks : ");
				c=sc.nextInt();
				System.out.println("Total marks : " + (a+b+c));
				int percentage=((a+b+c)/3);
				System.out.println("Percentage : "+ percentage);
				if(percentage>=75 && percentage<=100)
				{
					System.out.println("Grade A : FIRST CLASS");
			
				}
				else if(percentage>=55 && percentage<75)
				{
					System.out.println("Grade B : SECOND CLASS");
					
				}
				else if(percentage>=35 && percentage<55)
				{
					System.out.println("Grade C : THIRD CLASS");
				

		
				}
				else 
				{
					System.out.println("Grade D : FAIL");
			
					
				}
				
				
				
		
		
		
    }

			
		}
		
	
	

