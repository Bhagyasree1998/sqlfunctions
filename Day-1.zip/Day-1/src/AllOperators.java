
public class AllOperators {
	public static void main(String[] args) {
		
		int a=15,b=10;
		//Arithmetic operators
	System.out.println("Addition : " + (a + b));
    System.out.println("Subtraction : " + (a - b));
    System.out.println("Multiplication : " + (a * b));
    System.out.println("Division : "+ (a / b));
    System.out.println("Module : " + (a % b));
    // comparison operators
    System.out.println("(a > b)  : " + (a > b));
    System.out.println("(a < b) : " + (a < b));
    System.out.println("(a == b) : " + (a == b));
    System.out.println("(a != b) : "+ (a != b));
    System.out.println("(a >= b) : " + (a >= b));
    System.out.println("(a <= b) : " + (a <= b));
    System.out.println("Increment : " + ++a);
    System.out.println("decrement : " + --b);
    System.out.println("OR : " + (a|b));
    System.out.println("AND : " + (a&b));
    System.out.println("Complement : " + (~a));
    System.out.println("Right Shift : " + (a>>1 ));
    System.out.println("left Shift : " + (a<<1 ));
    
    
    
    
    
	}

}
