import java.util.Scanner;

public class EvenOdd {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
				int a,b,c,d,e,f;
				System.out.println("enter first number : ");
				a=sc.nextInt();
				d=a%10;
				System.out.println("enter second number : ");
				b=sc.nextInt();
				e=b%10;
				System.out.println("enter third number : ");
				c=sc.nextInt();
				f=c%10;
				
				if(d%2==0 && e%2==0 && f%2==0)
				{
					System.out.println("even" );
					System.out.println("Addition of three numbers : "+ (d+e+f));
					
				}
				else {
					System.out.println("odd");
			
					
					
					
				}
				
				

}
}
