
public class Arithmetic {
	static int a=5;
	int b=3;
	public static void main(String[] args) {
		
		Arithmetic sc=new Arithmetic();
		
	    System.out.println("Addition : " + (a + sc.b));
	    System.out.println("Subtraction : " + (a - sc.b));
	    System.out.println("Multiplication : " + (a * sc.b));
	    System.out.println("Division : "+ (a / sc.b));
	    System.out.println("Module : " + (a % sc.b));
	    
	  
	}
}
