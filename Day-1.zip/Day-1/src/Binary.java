
public class Binary {
	
		  public static void main(String[] args) {
		  System.out.println("Integer conversion");
		  int a = 50;
		  System.out.println("Integer: " + a);
		  
		  //integer to binary
		  
		  String by = Integer.toBinaryString(a);
		  System.out.println("Byte: " + by);
		  
		  //integer to hexadecimal
		  
		  String hex = Integer.toHexString(a);
		  System.out.println("Hexa decimal: " + hex);
		  
		  //integer to octal
		  String oct = Integer.toOctalString(a);
		  System.out.println("Octal: " + oct);
		  }
		}


