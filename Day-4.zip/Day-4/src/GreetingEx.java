
public class GreetingEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		English e=new English();
		e.morning();
		e.afternoon();
		e.evening();
		e.night();
		Hindi h=new Hindi();
		h.morning();
		h.afternoon();
		h.evening();
		h.night();
		Telugu t= new Telugu();
		t.morning();
		t.afternoon();
		t.evening();
		t.night();


	}

}
