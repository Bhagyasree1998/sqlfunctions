package com.inter;

public class University {
	String uname;
	String address;
	public University()
	{
		
	}
	public University(String unmae,String address)
	{
		this.uname=uname;
		this.address=address;
	}
	public void display()
	{
		System.out.println("University Name : "+uname+"Location : "+address);	
	}
	static class Electronics
	{
		String hodname;
		int experience;
		public Electronics()
		{
			
		}
		public Electronics(String hodname, int experience)
		{
			this.hodname=hodname;
			this.experience=experience;
		}
		public void displayElectronics()
		{
			System.out.println("HOD Name : "+hodname+"Experience"+experience);
		}
	}
	class Computer
	{
		String hodname;
		int experience;
	public Computer() 
	{
		
	}
	
public Computer(String hodname,int experience)
{
	this.hodname=hodname;
	this.experience=experience;
}
	void displayComputer()
	{
		System.out.println("HOD Name : "+hodname+"Experience"+experience);
	}
		class Electrical
		{
			String hodname;
			int experience;
			public Electrical()
			{
				
			}
			public Electrical(String hodname,int experience)
			{
				this.hodname=hodname;
				this.experience=experience;
			}
			public void displayElectrical()
			{
				System.out.println("HOD Name : "+hodname+"Experience"+experience);
			
			Electrical b=new Electrical();
			
		
		     b.displayElectrical();
			}
		}
	}
}
	

	
	
	
	
	


