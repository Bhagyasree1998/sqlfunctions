package com.inter;

public class UniversityEx {

	public static void main(String[] args) {
		University uni=new University("JNTU","Vizag");
		uni.display();
		University.Electronics ele=new University.Electronics("CLG",5);
		ele.displayElectronics();
		University electrical=new University()
				{
		public void displayElectrical(String hodname,int experience)
				{
			System.out.println("HOD Name : "+hodname+"Experience : "+experience);
				}
		// TODO Auto-generated method stub
	};
	b.displayElectrical("www",25);
	

}
}
