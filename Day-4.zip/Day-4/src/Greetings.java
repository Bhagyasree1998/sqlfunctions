
public interface Greetings {
	void morning();
	void afternoon();
	void evening();
	void night();
	
}

 class English implements Greetings{
	 
	 public void morning() {
		 System.out.println("Good Morning");
	 }
	 
	 public void afternoon() {
		 System.out.println("Good Afternoon");
		 
		  }
	 public void evening() {
		 System.out.println("Good Evening");
		 
		  }
	 public void night() {
		 System.out.println("Good Night");
		 System.out.println(" ");
		 
		  } 
	 }
 class Hindi implements Greetings{
	 public void morning() {
		 System.out.println("Subodaya");
	 }
	 
	 public void afternoon() {
		 System.out.println("Shubdopahar");
		 
		  }
	 public void evening() {
		 System.out.println("Shubsadhya");
		 
		  }
	 public void night() {
		 System.out.println("Subrathi");
		 System.out.println(" ");
		 
		 
		  } 
 }

 class Telugu implements Greetings{
	 public void morning() {
		 System.out.println("Namaskar");
	 }
	 
	 public void afternoon() {
		 System.out.println("Namaskar");
		 
		  }
	 public void evening() {
		 System.out.println("Namaskar");
		 
		  }
	 public void night() {
		 System.out.println("Namaskar");
		 
		  } 
 }
