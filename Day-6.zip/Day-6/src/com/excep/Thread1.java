package com.excep;

 class Thread1 extends Thread {
	 public void run()
	 {
		 for(int i=1;i<5;i++)
		 {
			 System.out.println("Thread1 "+i);
		 }
	 }

}
 class Thread2 extends Thread{
	 public void run()
	 {
		 for(int i=5;i<10;i++)
		 {
			 System.out.println("Thread2 "+i);
		 }
	 
 }
 }
 class Thread3 extends Thread{
	 public void run()
	 {
		 for(int i=11;i<15;i++)
		 {
			 System.out.println("Thread3 "+i);
		 }
	 
 }
 }
 class Thread4 extends Thread{
	 public void run()
	 {
		 for(int i=15;i<25;i++)
		 {
			 System.out.println("Thread4 "+i);
		 }
	 
 }
 }