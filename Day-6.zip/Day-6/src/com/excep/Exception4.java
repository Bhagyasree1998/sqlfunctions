package com.excep;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Exception4 {
	public static void main(String[] args) throws IOException {

		

		int n=10;
	    int[] m= new int[n];
	    try
	    {
	    FileReader f= new FileReader("dati.txt");
	         try
	         {
	         BufferedReader in =new BufferedReader(f);
	         }
	         catch(Exception e)
	         {
	         System.out.println("dati.txt not existing");
	         }
	    }
	    catch (Exception e)
	    {
	         System.out.println("File not Found Exception");
	    }
	    finally
	    {
	    int i=0;
	    BufferedReader in = null;
	String linea= in.readLine();
	    try
	    {
	    while(linea !=null)
	    {
	    String linea1 = null;
	m[i]=Integer.parseInt(linea1);
	    linea1 = in.readLine();
	    i++;
	    }
	    }
	    catch(Exception e)
	    {
	    System.out.println("NullPointer Exception");
	    }
	    BufferedReader f = null;
	
	    f.close();
	    }
	     }
	   
	}  





