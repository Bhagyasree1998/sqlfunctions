package com.inh;

public class RectangleMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box b=new Box();
		b.area();
		

	}

}
