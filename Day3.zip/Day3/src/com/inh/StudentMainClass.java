package com.inh;

public class StudentMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyRecord mr = new MyRecord();
		
		mr.name="BhagyaSree";
		mr.rollno=717;
		mr.marks=998;
		mr.percentage();
		mr.display();
		
	}

}
