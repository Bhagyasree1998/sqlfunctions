package com.inh;

public class NumberMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Derived d=new Derived();
		d.accept();
		d.display();
	}

}
