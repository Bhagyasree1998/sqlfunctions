package com.inh;

public class Student1MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Record r = new Record();
		
		r.name="BhagyaSree";
		r.rollno=717;
		r.address="Visakhapatnam";
		r.display();
	}

}
