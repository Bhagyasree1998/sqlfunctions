package com.inh;

public class HumanMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Woman w=new Woman();
		w.display();
		Man m=new Man();
		m.display();
		
	}

}
