package com.src;
import java.io.PipedReader;
import java.io.PipedWriter;
import java.io.IOException;

public class Pipe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
        {
            PipedReader ReaderEnd = new PipedReader();
            PipedWriter WriterEnd = new PipedWriter();
            
            ReaderEnd.connect(WriterEnd);
        
        for (int i = (int)('A'); i < ((int) ('z')) + 1; i++)
            WriterEnd.write((char) i );
         
        for (int i = (int)('A'); i < ((int) ('z')) + 1; i++ ) {
            int chr = ReaderEnd.read();
            
            System.out.print((char) chr);
        }
        } catch (IOException Ex)
        {
            System.out.println(Ex.getMessage());
        }

	}

}
