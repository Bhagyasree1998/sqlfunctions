package com.src;

import java.io.CharArrayWriter;
import java.io.FileWriter;
import java.io.IOException;

public class CharArray{
	public static void main(String args[]) {
	FileWriter fw=null;
	CharArrayWriter cw=null;
	try
	{
		fw=new FileWriter("text.txt");
		cw=new CharArrayWriter();
		char a[]= {'B','h','a','g','y','a'};
		cw.write(a);
		cw.writeTo(fw);
		System.out.println("Successfully Entered");
	}
	catch (IOException e)
	{
		e.printStackTrace();
	}
		cw.close();
		
		try {
			fw.close();
		}
		catch (IOException e) {
			e.printStackTrace();
			
	}
}
}
