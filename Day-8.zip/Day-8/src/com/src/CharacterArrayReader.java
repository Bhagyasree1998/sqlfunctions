package com.src;

public class CharacterArrayReader {

}
